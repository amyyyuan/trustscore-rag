| condition               |   trustrag_tpr |   trustrag_fpr_clean |   trustrag_fpr_collateral |
|:------------------------|---------------:|---------------------:|--------------------------:|
| fact_noprefix_m1        |          0.076 |                0.121 |                     0.130 |
| fact_noprefix_m5        |          0.907 |                0.121 |                     0.123 |
| fact_prefix_m1          |          0.090 |                0.121 |                     0.126 |
| fact_prefix_m5          |          1.000 |                0.121 |                     0.111 |
| inj_carrier_m1          |          0.084 |                0.121 |                     0.128 |
| inj_carrier_m5          |          0.346 |                0.121 |                     0.089 |
| inj_standalone_m1       |          0.061 |                0.121 |                     0.128 |
| inj_standalone_m5       |          0.966 |                0.121 |                     0.122 |
| inj_standalone_rep10_m1 |          0.000 |                0.121 |                     0.118 |
